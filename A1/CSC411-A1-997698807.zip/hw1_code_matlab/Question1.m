%% Clear workspace.
clear all;
close all;
%% Load all the data to be used
%load('mnist_test.mat');
load('mnist_train.mat');
load('mnist_train_small.mat');
load('mnist_valid.mat');

% Set up initial output diagram
output = zeros(2, 5);
n = 1;

for k = drange(1:2:9)
    i = 1;
    %valid_label = run_knn(k, train_inputs, train_targets, test_inputs);
    valid_label = run_knn(k, train_inputs, train_targets, valid_inputs);
    % Use this "difference" variable to hold a matrix of differences
    difference = valid_label - valid_targets;
    hit = 0;
    while i <= length(difference)
        % Count for hits
        if difference(i) == 0
            hit = hit + 1;
        end
        i = i + 1;
    end
    hit_rate = hit / length(difference);
    % Fill in the output diagram
    output(1,n) = k;
    output(2,n) = hit_rate;
    fprintf('when k = %d, the hit rate = %1.5f\n', k, hit_rate);
    n = n + 1;
end
plot(output(1,:), output(2, :));
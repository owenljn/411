%% Clear workspace.
clear all;
close all;

%% Load data.

load mnist_test;
train_inputs = test_inputs;
train_targets = test_targets;

%load mnist_train_small;
%train_inputs = train_inputs_small;
%train_targets = train_targets_small;

%load mnist_train;
load mnist_valid;

%% TODO: Initialize hyperparameters.
% Learning rate
hyperparameters.learning_rate = 0.01; % tried with smaller learning rate
% Weight regularization parameter 
hyperparameters.weight_regularization = 1;
% Number of iterations
hyperparameters.num_iterations = 100;
% Logistics regression weights
% TODO: Set random weights.
M = size(train_inputs);
% The weights here is set to a random M+1 by 1 matrix
weights = randn(M(2)+1, 1);



lambda = [0.001, 0.01, 0.1, 1.0];

 % Use a 4x2 matrix to represent average value of entropy and error
 % Note the first column of each matrix stores entropy/error of
 % training set and the second column is for the validation set
AvgEntropy = ones(4, 2);
AvgError = ones(4, 2);
for i = drange(1:4)
	%% Verify that your logistic function produces the right gradient, diff should be very close to 0
    % this creates small random data with 20 examples and 10 dimensions and checks the gradient on
    % that data.
    nexamples = 20;
    ndimensions = 10;
    diff = checkgrad('logistic_pen', ...
                    randn((ndimensions + 1), 1), ...   % weights
                    0.001,...                          % perturbation
                    randn(nexamples, ndimensions), ... % data        
                    rand(nexamples, 1), ...            % targets
                    hyperparameters);                        % other hyperparameters
                
    N = size(train_inputs, 1);
        
    tempEntropy = ones(4, 2);
    tempError = ones(4, 2);
    % Re-run logistic regression for 10 times
	for n = 1:10
        %hyperparameters.weight_regularization = lambda(i);
        hyperparameters.weight_regularization = 1;
        % These two variables store the iteration, cross-entropy, 
        % and classification error for both training and validation data.
        training_matrix = zeros(hyperparameters.num_iterations, 3);
        validation_matrix = zeros(hyperparameters.num_iterations, 3);
       %% Begin learning with gradient descent.
        for t = 1:hyperparameters.num_iterations

        %% TODO: You will need to modify this loop to create plots etc.

            % Find the negative log likelihood and derivative w.r.t. weights.
            [f, df, predictions] = logistic(weights, ...
                                           train_inputs, ...
                                           train_targets, ...
                                           hyperparameters);

            [cross_entropy_train, frac_correct_train] = ...
                evaluate(train_targets, predictions);
            training_matrix(t, :) = [t, cross_entropy_train, ...
                (1 - frac_correct_train)*size(train_targets, 1)]; 
  
            % Find the fraction of correctly classified validation examples.
            [temp, temp2, frac_correct_valid] = logistic(weights, ...
                                                 valid_inputs, ...
                                                 valid_targets, ...
                                                 hyperparameters);

            if isnan(f) || isinf(f)
                error('nan/inf error');
            end

            %% Update parameters.
            weights = weights - hyperparameters.learning_rate .* df / N;

            predictions_valid = logistic_predict(weights, valid_inputs);
            [cross_entropy_valid, frac_correct_valid] = ...
                evaluate(valid_targets, predictions_valid);
  
            % Now fill up the randomized validation matrix
            validation_matrix(t, :) = [t, cross_entropy_valid,...
                (1 - frac_correct_valid)*size(valid_targets, 1)];

            %% Print some stats.
            fprintf(1, 'ITERATION:%4i   NLOGL:%4.2f TRAIN CE %.6f TRAIN FRAC:%2.2f VALIC_CE %.6f VALID FRAC:%2.2f\n',...
                    t, f/N, cross_entropy_train, frac_correct_train*100, cross_entropy_valid, frac_correct_valid*100);
        end
        tempEntropy(n,:) = [mean(training_matrix(:, 2)), mean(validation_matrix(:, 2))];
        tempError(n,:) = [mean(training_matrix(:, 3)), mean(validation_matrix(:, 3))];
	 end
        AvgEntropy(i, :) = [mean(tempEntropy(:,1)), mean(tempEntropy(:,2))];
        AvgError(i, :) = [mean(tempError(:,1)), mean(tempError(:,2))];


end
    figure
    ax1 = subplot(2, 1, 1);
    ax2 = subplot(2, 1, 2);
    % Plot both average cross entropy and classification error on the same
    % figure.
    plot(ax1,lambda', AvgEntropy(:, 1), lambda', AvgEntropy(:, 2))
    title(ax1,'Average cross entropy')
    xlabel(ax1, '\lambda')
    ylabel(ax1,'Avg. CE')

    plot(ax2,lambda', AvgError(:, 1), lambda', AvgError(:, 2))
    title(ax2,'Average classification error')
    xlabel(ax2, '\lambda')
    ylabel(ax2,'Avg. error')%
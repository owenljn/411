function [ce, frac_correct] = evaluate(targets, y)
%    Compute evaluation metrics.
%    Inputs:
%        targets : N x 1 vector of targets.
%        y       : N x 1 vector of probabilities.
%    Outputs:
%        ce           : (scalar) Cross entropy. CE(p, q) = E_p[-log q]. Here we want to compute CE(targets, y)
%        frac_correct : (scalar) Fraction of inputs classified correctly.

% TODO: Finish this function
    % Set up the function of cross entropy, and calculate it
    ce = -(targets') * log(1-y) - ((1-targets') * log(y));
    
    % Compute hitrate
    hits = 0;
    for i = drange(1:size(targets, 1))
        if targets(i) == 0
            if y(i) >= 0.5
                hits = hits + 1;
            end
        else
            if y(i) < 0.5
                hits = hits + 1;
            end
        end
    end
    frac_correct = hits / size(y, 1);
end
